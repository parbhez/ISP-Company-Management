<template>
    <div>
        <div
            class="layout-wrapper layout-navbar-full layout-horizontal layout-without-menu"
            style="background-color: #1c222f"
        >
            <div class="layout-container" style="background-color: #1c222f">
                <h1>Page not found</h1>
            </div>
        </div>
        <!--/ Layout wrapper -->
    </div>
</template>
